#!/bin/bash

# OpenAI API Key (Replace with your actual key)
API_KEY="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"

# Iterate over batch files from db_batch2.jsonl to db_batch29.jsonl
for i in {2..29}; do
    FILE="db_batch${i}.jsonl"
    
    # Check if the file exists before attempting upload
    if [[ -f "$FILE" ]]; then
        echo "📤 Uploading $FILE..."
        
        curl https://api.openai.com/v1/files \
            -H "Authorization: Bearer $API_KEY" \
            -F purpose="batch" \
            -F file="@$FILE"
        
        echo "✅ Finished uploading $FILE"
        
        # Optional: Wait between requests to avoid hitting API rate limits
        sleep 5  
    else
        echo "⚠️ File $FILE not found, skipping..."
    fi
done

echo "🎉 All batches processed!"
