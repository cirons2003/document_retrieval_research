#!/bin/bash

# OpenAI API Key (Replace with your actual key)
OPENAI_API_KEY="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"

# Function to check OpenAI batch processing status
check_batch_status() {
    echo "🔄 Checking batch processing status..."
    
    # Get batch status from OpenAI
    RESPONSE=$(curl -s -H "Authorization: Bearer $OPENAI_API_KEY" "https://api.openai.com/v1/batches")
    
    # Count the number of in-progress batches
    IN_PROGRESS_COUNT=$(echo "$RESPONSE" | grep -Eo '"status": *"(in_progress|finalizing|cancelling)"' | wc -l)
    VALIDATING_COUNT=$(echo "$RESPONSE" | grep -o '"status": *"validating"' | wc -l)
    
    echo "📊 Currently, $IN_PROGRESS_COUNT batches are still processing."
    
    # If there are active batches, wait before proceeding
    while [[ "$IN_PROGRESS_COUNT" -ge 1 || "$VALIDATING_COUNT" -ge 1 ]]; do  # Ensuring only one batch is active at a time
        if [[ "$VALIDATING_COUNT" -ge 1 ]]; then
            echo "⏳ Batches are validating. Waiting before enqueuing the next batch..."
            sleep 45 # wait 45 min
        else
            echo "⏳ Too many batches in progress. Waiting before enqueuing the next batch..."
            sleep 1200 # wait 20 min
        fi
        RESPONSE=$(curl -s -H "Authorization: Bearer $OPENAI_API_KEY" "https://api.openai.com/v1/batches")
        IN_PROGRESS_COUNT=$(echo "$RESPONSE" | grep -Eo '"status": *"(in_progress|finalizing|cancelling)"' | wc -l)
        VALIDATING_COUNT=$(echo "$RESPONSE" | grep -o '"status": *"validating"' | wc -l)
        echo "📊 Updated batch count: $IN_PROGRESS_COUNT; validating count: $VALIDATING_COUNT"
    done
}

# Iterate over batch files from db_batch1.jsonl to db_batch29.jsonl
for i in {2..29}; do
    FILE="db_batch${i}.jsonl"
    
    # Check if file exists before attempting upload
    if [[ -f "$FILE" ]]; then
        echo "📤 Preparing to upload $FILE..."
        
        # Wait for previous batches to complete before uploading a new one
        check_batch_status
        
        # Upload file using OpenAI API to get file_id
        UPLOAD_RESPONSE=$(curl -s -X POST "https://api.openai.com/v1/files" \
            -H "Authorization: Bearer $OPENAI_API_KEY" \
            -F purpose="batch" \
            -F file="@$FILE")

        # Extract file ID from response
        FILE_ID=$(echo "$UPLOAD_RESPONSE" | grep -o '"id": *"file-[^"]*' | cut -d '"' -f4)

        if [[ -n "$FILE_ID" ]]; then
            echo "✅ Successfully uploaded $FILE (File ID: $FILE_ID)"
        else
            echo "❌ Upload failed for $FILE... $UPLOAD_RESPONSE"
            continue
        fi

        # Create batch using uploaded file ID
        BATCH_RESPONSE=$(curl -s -X POST "https://api.openai.com/v1/batches" \
            -H "Authorization: Bearer $OPENAI_API_KEY" \
            -H "Content-Type: application/json" \
            -d "{
                \"input_file_id\": \"$FILE_ID\",
                \"endpoint\": \"/v1/chat/completions\",
                \"completion_window\": \"24h\"
            }")

        # Extract batch ID
        BATCH_ID=$(echo "$BATCH_RESPONSE" | grep -o '"id": *"[^"]*' | cut -d '"' -f4)

        if [[ -n "$BATCH_ID" ]]; then
            echo "🚀 Successfully created batch (Batch ID: $BATCH_ID) for $FILE"
        else
            echo "❌ Batch creation failed for $FILE..."
        fi

        # Optional: Sleep before next upload to avoid rate limits
        sleep 5  
    else
        echo "⚠️ File $FILE not found, skipping..."
    fi
done

echo "🎉 All batches processed!"
